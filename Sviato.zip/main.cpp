#include <iostream>
#include <mpi.h>
#include <cmath>
#include <chrono>
#include <atomic>


inline std::chrono::steady_clock::time_point get_current_time_fenced() {
    std::atomic_thread_fence(std::memory_order_seq_cst);
    auto res_time = std::chrono::steady_clock::now();
    std::atomic_thread_fence(std::memory_order_seq_cst);
    return res_time;
}

template<class D>
inline long long to_us(const D &d) {
    return std::chrono::duration_cast<std::chrono::microseconds>(d).count();
}
using namespace std;
double starting_temperature(int x) {
    return sin(x);
}
int main(int argc, char** argv) {
    int commsize, rank, len;
    char procname[MPI_MAX_PROCESSOR_NAME];
    MPI_Init(&argc, &argv);
    MPI_Comm_size(MPI_COMM_WORLD, &commsize);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Get_processor_name(procname, &len);
    printf ("Hello, MPI World! Process %d of %d on node %s.\n",
            rank, commsize, procname);
    //-----------------------------

    const int length=40002, time=10;
    if((length-2)%commsize!=0||(length-2)<commsize)
        return 1;//Довжина яку обраховуємо мусить ділитись націло на кількість процесів
    int send_len=(length-2)/commsize;
    double values[length][time]={0}, start=0, end=0, heat_coef = 0.01;



    for(int i=0;i<time;i++) {
        values[0][i] = start;
        values[length-1][i] = end;
    }

    for(int i=1;i<length-1;i++)
        values[i][0]=starting_temperature(i);


    auto start_time=get_current_time_fenced();
    for(int i=0;i<time-1;i++) {
        double send_arr[send_len]={0};
        double recv_arr[length-2]={0};

        for (int j = 1+((length-2)/commsize*rank); j <= ((length-2)/commsize*(rank+1)); j++) {
            send_arr[j-(1+((length-2)/commsize*rank))] =
                    heat_coef * values[j - 1][i] + (1 - 2 * heat_coef) * values[j][i] +
                    heat_coef * values[j + 1][i];
        }

        MPI_Barrier(MPI_COMM_WORLD);
        MPI_Allgather(send_arr,send_len,MPI_DOUBLE,recv_arr,send_len,MPI_DOUBLE,MPI_COMM_WORLD);
        for(int o=0;o<length-2;o++){
            values[o+1][i+1]=recv_arr[o];
        }
    }
    auto end_time=get_current_time_fenced();
    if(rank==0) {
        printf(" The value of u[j,i] are:\n ");
        for (int i = 0; i < time; i++) {
            for (int j = 0; j < length; j++)
                printf("%7.4f\t", values[j][i]);
            printf("\n");
        }
        printf("Total time:%d\n",to_us(end_time-start_time));
    }





    //-----------------------------
    MPI_Finalize();
    return 0;
}